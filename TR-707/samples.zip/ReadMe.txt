Hello, heres all 15 TR 707 samples. Enjoy. All samples are public domain, so use em however ya
want.

Bass Drums 2x
	BassDrum1.wav           8.7  kb  Bass Drum1
	BassDrum2.wav           9.15 kb  Bass Drum2

Snare Drums 2x
	Snare1.wav		12.2 kb  Snare Drum1
	Snare2.wav		12.5 kb  Snare Drum2

Toms 3x
	HiTom.wav		57.0 kb  High Tom
	MedTom.wav		57.0 kb  Medium Tom
	LowTom.wav		56.6 kb  Low Tom

Hi Hats 2x
	HhC.wav			10.4 kb  HiHat Closed
	HhO.wav			28.2 kb  HiHat Open

Cymbals 2x
	Crash.wav		108  kb  Crash Cymbal
	Ride.wav		54.4 kb  Ride Cymbal

Others 
	Cowbell.wav		13.9 kb  Cowbell
	HandClap.wav		14.0 kb  Hand Clap
	RimShot.wav		7.11 kb  Rim Shot
	Tamb.wav		14.2 kb  Tambourine